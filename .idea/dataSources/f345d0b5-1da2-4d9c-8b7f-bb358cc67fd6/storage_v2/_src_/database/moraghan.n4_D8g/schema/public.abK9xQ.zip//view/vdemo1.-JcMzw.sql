create view vdemo1(id, file_name, file_size, contains_year_ind) as
SELECT demo.id,
       demo.file_name,
       demo.file_size,
       demo.contains_year_ind
FROM demo;

alter table vdemo1
    owner to moraghan;

