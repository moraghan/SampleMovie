create view vmovietitle
            ("TCode", "titleType", "primaryTitle", "originalTitle", "isAdult", "startYear", "endYear", "runTimeMinutes",
             genres, videotitle, videotitle1)
as
SELECT "title.basics"."TCode",
       "title.basics"."titleType",
       "title.basics"."primaryTitle",
       "title.basics"."originalTitle",
       "title.basics"."isAdult",
       "title.basics"."startYear",
       "title.basics"."endYear",
       "title.basics"."runTimeMinutes",
       "title.basics".genres,
       concat(replace("title.basics"."primaryTitle", ' '::text, ''::text), '.', "title.basics"."startYear",
              '.mkv')                                                              AS videotitle,
       concat(replace("title.basics"."primaryTitle", ' '::text, ''::text), '.mkv') AS videotitle1
FROM "title.basics"
WHERE "title.basics"."titleType" = 'movie'::text;

alter table vmovietitle
    owner to moraghan;

